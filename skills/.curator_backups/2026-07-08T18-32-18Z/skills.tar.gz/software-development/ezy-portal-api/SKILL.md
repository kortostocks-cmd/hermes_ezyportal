---
name: ezy-portal-api
description: "Class-level skill for working with EZY Portal REST API (Items, Categories, Item Groups, UOM Groups, Barcodes, Variants, Stats, Pricing, Sales Quotations). Covers authentication, endpoints, data models, pagination, masking, optimistic concurrency, variant handling, and the vivero tenant workflow."
category: software-development
tags: [ezy, portal, api, rest, items, inventory, pricing, vivero]
metadata:
  hermes:
    tags: [ezy, portal, api, rest, items, inventory, pricing, vivero]
    homepage: https://docs.ezyts.com/en/portal/
---

# EZY Portal API Development Skill

## When to Use
- Building integrations with EZY Portal (Items, Catalog, Pricing, Inventory, Sales Quotations, Business Partners)
- Writing API clients, scripts, or automation against `https://<tenant>.ezyts.com`
- Debugging API responses, pagination, masking, or variant matrix behavior
- Creating/updating items with nested prices, UOMs, barcodes, categories
- Creating or editing Sales Quotations (draft quotes)
- **Always load this skill first** before any EZY Portal work. The skill contains all endpoint URLs, auth patterns, pitfalls, and vivero-specific quirks.

## Authentication

| Endpoint Group | Auth Method | Header |
|----------------|-------------|--------|
| Items, Pricing-Tax, Commerce, Business Partners, Stats | Tenant API Key | `X-Api-Key: ten_...` |
| Accounts, Categories | Bearer JWT | `Authorization: Bearer <jwt>` |

**Critical**: Items and Accounts use DIFFERENT auth on the SAME domain. `X-Api-Key` works for Items but returns 401/404 for Accounts/Categories.

## Base URL
```
https://vivero.ezyts.com
```

## Key Endpoints

### Items
- `GET /api/items/items` — List (filters: `isActive`, `isSellable`, `query`, `sortBy`; expand: `prices`, `itemUoms`)
- `POST /api/items/items` — Create (omit `initialUOMs`, use `baseUom: "EA"`)
- `PATCH /api/items/items/{id}` — Update by UUID (NOT itemCode); requires `version` for optimism
- `GET /api/items/items/{id}` — Full detail
- `GET /api/items/items/by-code/{code}?expand=prices` — Lookup by itemCode (this endpoint returns prices even when list endpoint doesn't)
- `DELETE /api/items/items/{id}` — Soft delete (isActive=false)
- `GET /api/item-groups?perPage=50` — List item groups
- `GET /api/item-classes?perPage=50` — List item classes

### Pricing-Tax
- `GET /api/pricing-tax/price-lists?perPage=50` — List all price lists (paginated response: `{data: [...], hasMore, total}`)

### Sales Quotations
- `GET /api/commerce/sales-quotations?expand=lines` — List (always use expand)
- `POST /api/commerce/sales-quotations` — Create (accepts `lines[]` inline)
- `PATCH /api/commerce/sales-quotations/{id}` — Update draft

### Business Partners
- `GET /api/business-partners/bp` — List (paginated)
- `POST /api/business-partners/bp` — Create (requires `Idempotency-Key` header)

### Payment Terms
- `GET /api/business-partners/payment-terms` — Returns FLAT LIST (not paginated dict). No `data` wrapper.
- Available (Jul 2026 vivero): COD (Contra Reembolso), DUE_RECEIPT, NET15/30/45/60/90, PREPAY
- **Verified working ID for SO creation (Aug 2026)**: `9025dae9-6d36-465b-a98f-733966ef8f37` (used by Viveros Mi Jardin and Viveros Ian BPs). The `/api/pricing-tax/payment-terms` endpoint returns 404 — use BP payment terms IDs directly.
- `paymentTermsId` is REQUIRED at top level for SO creation.

### Warehouses
- `GET /api/inventory/warehouses` — Returns FLAT LIST. Endpoint is `/api/inventory/warehouses`, NOT `/api/warehouses` (404) or `/api/warehouses/warehouses` (404).
- **Pitfall**: Warehouse endpoint returns flat array, not paginated dict. Confirmed PRINCIPAL warehouse: `95c298a9-54d8-4c51-ae78-5c3b76cac657` (code: PRINCIPAL, name: ALMACEN PRINCIPAL).
- Available (Jul 2026 vivero): code=`PRINCIPAL`, name=`ALMACEN PRINCIPAL`, description=`METRO PARK`

## Pagination\n- `page`, `perPage` — **max ~25 per page on vivero tenant** (perPage=29 works, perPage=30+ returns 400 `Invalid query parameters`)\n- Response: `total`, `hasMore`\n- Always paginate — use perPage=25 and iterate via `hasMore`\n- Example pagination loop:\n```python\npage = 1\nwhile True:\n    url = f\"{PORTAL_URL}/api/items/items?isActive=true&perPage=25&page={page}\"\n    # ... fetch via curl subprocess ...\n    items = data.get(\"data\", [])\n    if not items or not data.get(\"hasMore\"):\n        break\n    page += 1\n```

## vivero Tenant (Panamá)

### User Preferences
- **Language**: Spanish only. Respond concisely — no explanations, no theory, no "what would you like to do next". Just data, status, next action.
- **Style**: Deliver working artifacts backed by real tool output. Do not stop after writing a plan or stub. Keep executing until the artifact is complete.
- **Data integrity is critical**: If a dedup check produces a skip list, the user expects those items to ALSO end up in the target sheet, not just the portal. Missing data will be caught and called out.
- **Report final counts clearly**: "44 created, 47 skipped, 210 total in sheet" — tabular, not prose.

### Item Code Convention
Pattern: `PL-` + UPPERCASE_NAME_WITH_DASHES. Name and code must match: name `LIRIO GIGANTE` → code `PL-LIRIO-GIGANTE`.

### Code Generation with Parentheses Conflict Resolution

When generating item codes from sheet names containing parenthetical content (e.g. "FICUS LYRATA (HASTA 200CM)", "GUAYACAN ENANO (TECOMA)"):

**Rule: "no pongas el paréntesis en el código sino el nombre"** — keep parentheses in the display name but strip them from the code. Use a dual-function approach:

```python
def slugify(name):
    """Normalize name for code — strips parenthetical content entirely"""
    s = re.sub(r"\s*\([^)]*\)", "", name.strip()).strip()
    s = s.upper()
    s = s.translate(str.maketrans("ÑÁÉÍÓÚÜ", "NAEIOUU"))
    s = re.sub(r"[^A-Z0-9\s]", "", s)
    s = re.sub(r"\s+", "-", s.strip())
    return s

def slugify_raw(text):
    """Normalize text WITHOUT stripping parentheses — for conflict suffix extraction"""
    s = text.strip().upper()
    s = s.translate(str.maketrans("ÑÁÉÍÓÚÜ", "NAEIOUU"))
    s = re.sub(r"[^A-Z0-9\s\(\)]", "", s)
    s = re.sub(r"\s+", "-", s.strip())
    s = re.sub(r"[()]", "", s)
    return s
```

**Conflict detection**: After generating `PL-` + slugify(name), check if the code already exists in a `seen_codes` set. If it does:

```python
paren_match = re.search(r"\(([^)]*)\)", name)
if paren_match:
    extra = slugify_raw(paren_match.group(1))  # e.g. "HASTA-200CM"
    code = base_code + "-" + extra               # e.g. PL-FICUS-LYRATA-HASTA-200CM
```

**Real example (Jul 6 2026)**:
| Sheet name | Code (auto) |
|---|---|
| FICUS LYRATA | PL-FICUS-LYRATA |
| FICUS LYRATA (HASTA 200CM) → renamed to FICUS LYRATA GRANDE | PL-FICUS-LYRATA-GRANDE |
| FICUS LYRATA 3 RAMAS (HASTA 175CM) | PL-FICUS-LYRATA-3-RAMAS |

Note: "FICUS LYRATA 3 RAMAS" slugifies to "FICUS-LYRATA-3-RAMAS" (different from "FICUS-LYRATA") so it doesn't need a parenthetical suffix. Only when the base slugify output is identical does the conflict resolver activate.

### Code Convention for Non-Plant Items

Items that are NOT plants (cajas, supplies, etc.) get codes WITHOUT the `PL-` prefix when the user explicitly requests it:
- `CAJA POTE 120_1000PCS` → `CAJA-POTE-1201000PCS`
- `CAJA POTE 180_450PCS` → `CAJA-POTE-180450PCS`

These are still created as `itemType: "stock"`, `isSellable: true` — they are valid sellable items, just with a different code convention.

### Stock Field
Use `itemStockTotal` — NOT `stockTotal` (doesn't exist). Use `itemAvailableTotal` for stock excluding pending orders.

### Price List IDs (Verified Jul 2026)

Current active price lists (always verify fresh each session):

| Code | ID | Note |
|------|-----|------|
| COST_A&G | 3957783e-b384-4bf9-a6a5-7982f7ad8d2f | |
| COST_EDWIN | d1eeecb8-e5a8-4f89-90d8-fc4a6480f902 | |
| COST_HACIENDA | 0dbfdd7b-db25-4040-a90b-5f452378de86 | |
| COST_SUGEY | e38bab32-70c5-4b66-b16c-dc5cdb2dbaa4 | New Jul 2026 |
| COST_SARACELY | 65399687-8f36-46af-8145-01b5d50198f0 | New Jul 2026 |
| COST_MIJARDIN | fbd1e2fc-9386-4e7b-b8ee-b4ec501eead1a | New Jul 2026 |
| **SALE_EXTRA** | **13ce22b6-0b29-4029-be65-42e8c23cb239** | **Only active sales price list (Aug 2026). SALE_PUBLIC and SALE_SUPER no longer exist.** Use for ALL Super Xtra branches. |

> **CRITICAL**: `SALE_PUBLIC` and `SALE_SUPER` **no longer exist** in the tenant as of Jul 2026. If you need a sales price list, use `SALE_EXTRA`.
> 
> `COST_IAN`, `COST_JARDIN`, `COST_SARA`, `COST_ISMAEL`, and `COST_EDUARDO` also do not exist in the current tenant. Always verify via `GET /api/pricing-tax/price-lists?perPage=50` each session.

### Item Group & Class (fetch fresh each session, DO NOT hardcode)
Fetch at the START of every session:
```
GET /api/items/item-groups?perPage=50
GET /api/items/item-classes?perPage=50
```
As of Jun 30 2026 (will drift):
- PLANTS group: `b38e9a2d-4951-4d40-9fa3-1357ef0dc631`
- LIVE_PLANT class: `b65da4ee-1f20-45f7-b329-d2b884c7c10d`
**"Item class not found" error means the IDs are stale** — re-fetch immediately.

### Google Sheet
ID: `1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE`
Tabs: INVENTARIO (A=PLANTA, B=FOTO, C=STOCK, D=PRECIO), plantas_nuevas (CODIGO, NOMBRE, LISTA_PRECIO, PRECIO_USD, STOCK, DESCRIPCION)
Token: `~/.hermes/profiles/ezy_portal_expert/google_token.json`

## Cloudflare SSL Workaround
Python `urllib` against `vivero.ezyts.com` gets HTTP 403 (error 1010) without Mozilla User-Agent + SSL context:
```python
import ssl, urllib.request
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
req = urllib.request.Request(url)
req.add_header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36")
```

**Newer API keys (ten_3HW_... onwards) also get 401 from urllib on ALL portal endpoints** even with the Cloudflare workaround. This happens in hermes-agent venv Python (uv-managed) even though curl works fine and the headers are correct. Use `curl` via subprocess for ALL portal API calls with these keys — do not use Python urllib:
```python
import subprocess, json
result = subprocess.run(["curl", "-s", "-H", f"X-Api-Key: {API_KEY}", "-H", "User-Agent: Mozilla/5.0",
    "https://vivero.ezyts.com/api/items/items?perPage=100&page=1"],
    capture_output=True, text=True, timeout=30)
data = json.loads(result.stdout)
```

### Sales Orders (SO) — New Endpoint (discovered Jul 2 2026)

`POST /api/commerce/sales-orders` — Same payload structure as Sales Quotations, but produces `SO-` prefixed document numbers.

Key differences from Sales Quotations:
- **Status**: Always created as `DRAFT`; check `availableTransitions` to see next status
- **Line validation is stricter**: `"Item: item is not active"` error if any line references an inactive item. Always verify `isActive=true` before adding to sales orders.
- **SO requires MORE line-level fields than SQ**: `itemId`, `itemName`, `warehouseId`, `warehouseCode`, `warehouseName`, `taxCategoryId`, `taxCategoryCode`, `taxCategoryName`, `uomCode` — ALL are required. Missing any except itemCode gives `"incomplete data"`.
- **Item UUID drift (CRITICAL)**: The `/api/items/items` list endpoint and `/api/items/items/by-code/{code}` endpoint return DIFFERENT UUIDs for the same itemCode within the SAME session. The by-code endpoint returns the canonical IDs; the list endpoint returns stale/divergent IDs. Always fetch IDs fresh via by-code at session start. Using list-endpoint IDs in SO payloads gives `"Item: item not found"`.
- **warehouseId is REQUIRED per line** (not just code/name)
- **Field name**: `quantity` NOT `qty`
- **Date format**: ISO 8601 with T (`"2026-06-05T00:00:00Z"`)
- **Payment terms**: `paymentTermsId` is REQUIRED at top level. Verified working ID: `9025dae9-6d36-465b-a98f-733966ef8f37`. The endpoint `/api/pricing-tax/payment-terms` returns 404; use BP payment terms IDs directly.
- **Reference**: use `"reference": "Factura No.{number}"` for invoice-linked orders.
- **⚠️ BP code=None workaround**: BPs created via portal UI sometimes have `bpCode: null`. The SO endpoint validates `bpCode` as required — returns `"Key: 'CreateSalesOrderRequest.BPCode' Error:Field validation for 'BPCode' failed on the 'required' tag"`. Pass an arbitrary string as `bpCode` (e.g. "SABANITAS", "CONDADO") alongside `bpId` and `bpName`. The API stores it on the document.
- **validUntil**: Set to `documentDate + 30 days` (e.g., `"2026-07-05T00:00:00Z"`).
- **Response key**: uses `documentNumber` (NOT `orderNumber`). Response format: `{"id", "documentNumber": "SO-2026-000025", ...}`.
- **Total**: May return `null` (`"totalAmount": null`) for draft orders — prices are calculated on finalization, not on draft creation.
- **Pre-creation summary**: MUST be a compact table — NOT verbose prose. Show: Cliente, Factura/N° referencia, Fecha, Líneas, Total. Ask "¿Creo la orden?" concisely. User responds with "dle" or "dle+" to confirm.
- **urllib vs curl**: Some API keys (`ten_Zk271...`) work fine with Python urllib for SO creation; others (`ten_3HW_...`) get 401. Prefer curl via subprocess for reliability. For complex payloads (22+ lines), write to `/tmp/so_<branch>.json` first, then `curl -s -X POST ... -d @/tmp/so_<branch>.json`. The urllib approach (via execute_code) can succeed if item UUIDs are correct and the key supports it.

### Sales Documents — User Preference (vivero tenant, Jul 2026)

The user manages **8+ customer branches** of SUPER EXTRA (same RUC 356-19-77860):
1. **via israel** (CL-0035, id=32249c40-4c89-4fdf-a381-73969dba188d)
2. **los pueblos** (CL-0005, id=a8cea960-d200-4222-8654-6cda0093d6b9)
3. **albrook** (CL-0017, id=db64ad3e-a54c-4f15-b15b-d60dba3917a4)
4. **monterico** (CL-0006, id=083fb553-ca57-4678-ba12-9ae1cf4b90ed)
5. **el Lago** (CL-0019, id=78532e5e-caa7-4863-aa80-7090e8e22257)
6. **las acacias** (CL-0004, id=6bf480fd-4f62-41da-a4a6-353541fce16f)
7. **las tablas** (CL-0024, id=cbb72b57-a924-408d-9772-ca7de21834ae)
8. **chorrera** (CL-0002, id=3d7f8040-61ea-45dd-b42d-97721513f018)

**Price list per client type:**
- **SUPER EXTRA** (all branches): Use `SALE_EXTRA` (id=`13ce22b6-0b29-4029-be65-42e8c23cb239`) — SALE_SUPER and SALE_PUBLIC no longer exist as of Aug 2026.

**Document type preference: SALES ORDERS (SO) over Sales Quotations (SQ)**
- As of Jul 2 2026, user prefers **Sales Orders** (`POST /api/commerce/sales-orders`) for all Vivero Rose invoices. Sales Quotations were an earlier draft-only approach.
- SO endpoint accepts identical payload structure to SQ, but produces `SO-` prefixed document numbers.
- SQ drafts created earlier were deleted by the user — always use SO endpoint going forward.

When creating orders from Vivero Rose invoices:
- **ALWAYS show pre-creation summary** (cuántos items, total, fecha, cliente) and ask for confirmation before creating — user insists on this
- **CRITICAL: Do NOT add extra items not in the invoice.** The user explicitly stopped work when extra sale items were attempted. Only include items exactly as listed on the invoice (or with N/C excluded). If an item fails validation (e.g., inactive), fix the item directly, don't skip silently and don't substitute with a different item without asking.
- Items that are not plants (tierra negra, cascarilla de arroz, fletes, caja pote) are excluded unless user says otherwise
- **Reference field** = `"Factura No.{number}"` (e.g., "Factura No.741")
- **Date = expiration date** (validUntil = documentDate)
- **Precio de factura** se pone manualmente (unitPrice), no se usa el precio del portal
- Items que no existen en portal se reemplazan por el más cercano existente con `description` anotando el nombre original
- Items with "N/C" (anotado en rojo en la factura) se excluyen de la orden — preguntar si no está claro
- **DO NOT auto-exclude items from past sessions** — each invoice is processed independently. Just because an item was excluded in a previous order (e.g., MARIGOLD was excluded in Jun 2026) does not mean it should be excluded now. The user will ask '¿por qué sin X?' if you remove something they didn't say to remove. Only exclude if the current invoice explicitly marks N/C or the user says to exclude now.
- **If a line fails with `"item is not active"`**: reactivate the item via PATCH `{isActive: True, version}`, then retry the full payload. Do NOT skip the line without asking.

### Item Name Corrections & Sheet Matching (vivero tenant, Jul 2 2026)

**From Vivero Rose invoices → Sheet INVENTARIO names:**

| Invoice name | Sheet name |
|---|---|
| HIERBA BUENA | HIERBA BUENA |
| MENTA | MENTA |
| ROMERO | ROMERO |
| ALBAHACA | ALBAHACA VERDE |
| ORÉGANO | OREGANO |
| TOMILLO | TOMILLO |
| RUDA | RUDA |
| CHAVELITAS | CHAVELITAS |
| CINTAS / CINTA MALA MADRE | CINTA MALA MADRE |
| CACTUS (variados) | CACTUS MEDIANO |
| CORONITAS | CORONITA |
| CLAVELES / CLAVELITO | CLAVELITO |
| TORENIAS | TORENIA |
| JADE | JADE |
| MINI JADE | MINI JADE |
| CRISANTEMOS | CRISANTEMOS |
| AJÍ BOLITA | AJI BOLITA |
| NOVIOS / NOVIAS | NOVIO CHINO |
| LENGUA MINI | LENGUA DE SUEGRA MINI |
| LENGUA ENANA | LENGUA DE SUEGRA ENANA |
| PETUNIN | PETUNIN |
| CELOCIA | CELOCIA |
| ROSA | ROSA |
| PALMA ROJA | PALMA ROJA |
| ROSITA MINIATURA | ROSITA MINIATURA |
| SUCULENTAS VARIADAS PEQUEÑA | SUCULENTA PEQUEÑA |
| SUCULENTAS VARIADAS MEDIANA | SUCULENTAS MEDIANAS |
| SUCULENTAS VARIADAS GRANDE | SUCULENTAS GRANDE |
| IXORA | IXORA |
| FITONIA ROJA | FITONIA ROJA |
| SÁBILA ALOE PEQUEÑA | SABILA ALOE PEQUENA |
| MOLLEJA / MOLLEJITAS | MOLLEJA |
| APIO | APIO |
| CIELITO AZUL | CIELITO AZUL |
| ZAMIOCULCA | MILLONARIA ZAMIOCULCA |
| ZAMIOCULCA NEGRA | MILLONARIA ZAMIOCULCA NEGRA |
| CAÑA DEL BRASIL | PALO DE BRASIL |
| ALOCASIA LAVA | ALOCASIA LAVA ROJA |
| FICUS TRIANGULAR | FICUS TRIANGULAR GRANDE |
| HELECHO | HELECHOS |
| PALO DE BRASIL DE ESCRITORIO | PALO DE BRASIL DE ESCRITORIO |
| CACTUS HUESO DE DRAGÓN | CACTUS HUESO DE DRAGON |
| CELOSIA | CELOCIA |
| BOMBERO | = ROMERO (sumar cantidades) |
| CHOCOLATE | = CHAVELITAS (sumar cantidades) |
| MINI UVAS | Excluir / no existe en portal |
| MARIGOLD VR | PL-MARIGOLD-VR (crear item nuevo si no existe)
| PHOTUS VR | PHOTUS (PL-PHOTUS)
| TRADESCANTA ZEBRINA CUCAR / TRADESCANTIA ZEBRINA CUCARACHA | TRADESCANTIA ZEBRINA CUCARACHA (PL-TRADESCANTIA-ZEBRINA-CUCARACHA)

### Bulk Import Name Overrides (Jul 6 2026)
When importing INVENTARIO sheet items to portal via bulk create, the user applies these overrides:
- **FICUS LYRATA (HASTA 200CM)** → rename to **FICUS LYRATA GRANDE** (code: PL-FICUS-LYRATA-GRANDE). Name strips the parenthetical, replaces with GRANDE.
- **FICUS LYRATA 3 RAMAS (HASTA 175CM)** → keep as **FICUS LYRATA 3 RAMAS (HASTA 175CM)** (code: PL-FICUS-LYRATA-3-RAMAS). Name includes parenthetical.
- **MONSTERA ADANSONII** → include exactly **1** (not 0, not 2). Sheet has 2 identical rows (106, 107) — deduplicate to one.
- **CAJA POTE 120_1000PCS, CAJA POTE 180_450PCS** → create as full items (stock type, isSellable=true) with code WITHOUT PL- prefix. Code = CAJA-POTE-1201000PCS / CAJA-POTE-180450PCS.

### Items to Ask Before Creating
- BOMBERO, CHOCOLATE, MINI UVAS — these are unknown plant names, ask user what they refer to
- FLETES, CAJA POTE — non-plant items, excluded by default in sales orders; create with code WITHOUT PL- prefix when user explicitly requests it

## Source of Truth Preference

As of Jul 2 2026, the user prefers comparing against the **Google Sheet INVENTARIO tab** as the source of truth for item names and existence, NOT the EZY Portal API. He plans to migrate the portal within a week. When matching:
1. Read INVENTARIO!A:A from the sheet
2. Normalize: NFKD + ASCII + UPPERCASE + strip non-alphanumeric
3. Match against user's list
4. For items not found, try partial word matching
5. Present both the exact matches and ambiguities to the user for resolution

**Updated Aug 1 2026**: User explicitly asked to compare against **Airtable** (sortable via `vivero.ezyts.com`) instead of the old INVENTARIO sheet, since the sheet will be migrated. The `alohomora` backup in Airtable (`appIQ4f4j6c2bMPlb`) is now the preferred source of truth for stock reconciliation.

### Invoice Processing (Factura) Workflow — protego
Each invoice from a supplier is processed independently. See `references/factura-reading-workflow.md` for the complete workflow. Key constraints:
- **Do NOT mix invoices** — each invoice is its own order. User said "no mezcles" and "solo esta imagen no mezcles".
- **Do NOT sum stock** — report invoice items as they appear
- **Show summary before creating** — user must confirm before order creation
- **Only process what was asked** — respect "no mezcles" and "solo esta imagen"
- **Sales order status: DRAFT** — user prefers draft orders, not confirmed
- **Compact terminal output**: User says "usa compact en tus commandos" — use concise `curl -s` (no verbose `-v` flags), pipe through `python3 -c` for minimal extracted output, avoid raw json dumps. Output compact tables, not verbose prose. Store large JSON payloads as files (`/tmp/so_<branch>.json`) and reference with `-d @file`.
- **Confirmation keyword**: User responds "dle" or "dle+" to confirm — do not ask "¿Estás seguro?" or wait for full sentences. Just "¿Creo la orden?" and they'll reply "dle".
- **Invoice date extraction**: Always read the date from the invoice image. Use ISO 8601 format with T for the API (`"2026-06-05T00:00:00Z"`).

When items needed for a quotation are inactive (`isActive=false`):
1. Fetch ALL items (paginated, active + inactive)
2. Filter inactive: `[i for i in all_items if not i.get("isActive", True)]`
3. PATCH each with `{"isActive": True, "version": version}`
4. On 409 Conflict, retry with `version + 1`

On Jul 1 2026: 57 items reactivated, 0 failures.

**CRITICAL**: Item UUIDs can CHANGE between sessions (re-fetch needed).
**CRITICAL**: `POST /api/items/items/{id}/restore` may return 200 but NOT actually activate the item. Use PATCH instead.

## Spells (Harry Potter CLI convention)

### lumos — Portal → Google Sheet (VERIFIED OK)\nSync portal stock + SALE_SUPER prices → INVENTARIO tab.\n- Script: `scripts/lumos.py`\n- Run: `~/.hermes/hermes-agent/venv/bin/python3 skills/software-development/ezy-portal-api/scripts/lumos.py`\n- Normalizes names (strip accents, VR suffix, parentheticals) for matching\n- Compacts empty rows automatically\n- Updates ALL rows unconditionally (not just empty ones)\n\n**AFTER lumos runs, ALWAYS check for gaps** (items in portal not in sheet):\n  `~/.hermes/hermes-agent/venv/bin/python3 skills/software-development/ezy-portal-api/scripts/check_sheet_gaps.py`\n  - Script: `scripts/check_sheet_gaps.py`\n  - Prints count + list of missing items\n  - Use the output to decide whether to add missing rows to the sheet\n  - On Jul 2 2026: 224 portal items vs 210 in sheet = 38 missing

### alohomora — Portal → Airtable (PARTIAL)
Backup items + BPs to Airtable base `appIQ4f4j6c2bMPlb`.
- Script: `scripts/alohomora.py`
- Tables: tblTXfSmRyVPV6Tv1 (Items), tblXKTjY4kjgnPdTb (BPs)

### stupefy — Sheet → Portal (ad-hoc)
Bulk create/update items from Google Sheet rows.
- Workflow: `references/spell-commands.md` and `references/bulk-creation-workflow.md`

## Creating Items via POST — Critical Workflow

### Pre-creation: Check for duplicates
1. Fetch ALL active portal items (paginate 100/page)
2. Build `portal_by_name[name.upper().strip()]` and `portal_by_norm[normalize(name)]`
3. For each source row, check exact name match first, then normalized
4. Also check by itemCode if provided

**⚠️ Fresh portal (no existing items):** Skip the dedup phase entirely. `GET /api/items/items` returns `total: 0`. Go straight to creating.

### POST payload
```python
{
    "itemCode": "PL-NEW-ITEM",
    "name": "NEW ITEM NAME",
    "description": "New Item.",
    "itemType": "stock",
    "isStock": True,
    "isPurchasable": True,
    "isSellable": True,
    "baseUom": "EA",
    # OMIT initialUOMs — causes chk_uom_code SQL error
    "itemGroupId": GROUP_ID,       # fetch fresh! OPTIONAL — omit if no groups exist yet
    "itemClassId": CLASS_ID,       # fetch fresh! OPTIONAL — omit if no classes exist yet
    "defaultSalesTaxCategoryId": TAX_ID,
    "defaultPurchaseTaxCategoryId": TAX_ID,
    "prices": [{
        "priceListId": PL_ID,
        "priceListCode": "COST_HACIENDA",
        "price": 20.00,
        "currencyCode": "USD"
    }]
}
```

### Minimal Payload (MARIGOLD pattern, Aug 2026)
To create a simple sellable item with NO groups, classes, or prices (add those later):
```python
{
    "itemCode": "PL-MARIGOLD-VR",
    "name": "MARIGOLD VR",
    "description": "MARIGOLD VR",
    "itemType": "stock",
    "isStock": True,
    "isPurchasable": True,
    "isSellable": True,
    "isActive": True,
    "baseUom": "EA",
    "defaultSalesTaxCategoryId": "097722df-e70c-4380-9372-a863c67c2bca",
    "defaultPurchaseTaxCategoryId": "097722df-e70c-4380-9372-a863c67c2bca"
}
```
This creates an item with `isActive: true` (no need for post-patch), `defaultSalesTaxCategory: EXCENTO`, and `version: 1`. Item is immediately usable in sales orders. Tested with `ten_Zk271...` API key via urllib (no CA cert issues).

### Pitfalls
1. **"Item class not found"** → itemGroupId or itemClassId UUIDs are wrong. Fetch fresh from /api/items/item-groups and /api/items/item-classes.
2. **POST response omits itemCode** → use id from response for tracking, not the code field.
3. **Unparseable prices** → sheet values like "10/20/30" (range notation) break float(). Catch ValueError and default to 0.
4. **DUPLICATE item code** → check existing items by code AND name before creating.
5. **Price masking on success** → prices: [] in PATCH response doesn't mean write failed. Check version increment (1→2 = success).
6. **Barcodes need UOMs first** — POST creates items WITHOUT itemUoms. The /api/items/items/{id}/barcodes endpoint requires an itemUomId. Until UOMs are added via PATCH, barcodes cannot be generated.
7. **Category assignment via PATCH works with API key** — even though GET /api/categories requires Bearer JWT, setting itemCategory + tags on PATCH /api/items/items/{id} works with X-Api-Key. See references/vivero-category-mapping.md for category UUIDs.
8. **itemType enum: "nonstock" is INVALID** — The itemType field on POST accepts only specific enum values (e.g. "stock", "service"). "nonstock" returns 400 'Field validation for ItemType failed on the oneof tag'. Always use "stock" for physical items (plants, cajas, supplies). If unsure, omit it — the server defaults to "stock".

### Stupefy Dedup-Sheet Gap (CRITICAL)
When bulk-creating items from a Google Sheet to the portal via stupefy workflow:

1. **Dedup phase** checks portal for existing items → produces `skip_list` (already in portal) and `create_list` (new).
2. **Create phase** sends only `create_list` to the portal API.
3. **Sheet phase** MUST append BOTH `create_list` AND `skip_list` to the target sheet tab.

**The bug**: Only appending `create_list` causes 30-50% of expected plants to vanish from the sheet. The user will notice and call this out.

**The fix**: Always union both lists before writing to the sheet:
```python
all_to_add = [n for _, n, _, _ in create_list] + [n for _, n, _, _ in skip_list]
# Sort, then write to sheet
```

### Post-Creation Fix: isActive + itemGroup (CRITICAL)
Items created via `POST /api/items/items` have `isActive: false` and `itemGroup: null` by default. They WILL NOT appear in the portal's item list view — only in search.

**After bulk creation, ALWAYS patch all new items:**
```python
patch = {"version": version, "isActive": True, "itemGroup": GROUP_ID}
# PATCH /api/items/items/{id} with this payload
```
Without this step, the user will report "no encuentro las bandejas" / "solo en buscar todo".

**⚠️ Fresh portal — no groups/classes exist yet:**
On a brand-new tenant (no item groups, no item classes), the POST endpoint accepts items without `itemGroupId` and `itemClassId`. The PATCH to set isActive should also omit `itemGroup` if the groups endpoint returns empty:
```python
groups = curl_get("/api/items/item-groups?perPage=50")
if groups["data"]:
    patch["itemGroup"] = groups["data"][0]["id"]   # use first group
else:
    patch = {"version": version, "isActive": True}  # no group to assign
```
Fetch groups/classes fresh at the start of every session — IDs drift between sessions.

### Price Lists Endpoint is Paginated
Since Jun 30 2026, `GET /api/pricing-tax/price-lists` returns a **paginated response** `{data: [...], hasMore, total}` — NOT a flat array. Always use `perPage=50` and iterate:
```python
result = curl_get("/api/pricing-tax/price-lists?perPage=50")
for pl in result["data"]:
    price_lists[pl["code"]] = pl["id"]
```

### urllib 401 with Some API Keys
Older keys (`ten_3HW_...`) get **HTTP 401** from Python urllib on ALL portal endpoints even with Mozilla UA + SSL workaround. Newer keys (`ten_Zk271...`) work fine with urllib. When urllib gives 401, use `curl` via subprocess instead:
```python
import subprocess, json
result = subprocess.run(["curl", "-s", "-H", f"X-Api-Key: {API_KEY}", "-H", "User-Agent: Mozilla/5.0",
    "https://vivero.ezyts.com/api/items/items?perPage=100&page=1"],
    capture_output=True, text=True, timeout=30)
data = json.loads(result.stdout)
```

## Common Pitfalls (condensed)
- `itemStockTotal` includes items on order → use `itemAvailableTotal` for sellable stock
- PATCH requires UUID, not itemCode → always fetch `/by-code/{code}` first
- PATCH with `prices` replaces entire array, doesn't merge
- Missing `version` on PATCH → 409 Conflict
- `expand=prices` on list endpoint returns items WITHOUT prices key; use `/by-code/{code}?expand=prices` instead
- **Sales Quotations: `lineNumber` is REQUIRED** on every line — sequential integers starting from 1. All lines with `lineNumber: 0` cause `"duplicate lineNumber values: [0]"` error.
- **Sales Quotations: All line fields required** — `itemId`, `itemCode`, `itemName`, `warehouseId/Code/Name`, `taxCategoryId/Code/Name`, `uomCode` — even `unitOfMeasure`. Missing any causes per-line validation failure.
- **Sales Quotations: `expand=lines` may return empty** in subsequent GET even when lines were saved — trust `grandTotal` as ground truth.
- **Item UUIDs drift within-session and between-sessions** — by-code endpoint returns different UUIDs than the list endpoint. Always fetch fresh via `/api/items/items/by-code/{code}` at session start. Never reuse list-endpoint IDs for SO payloads.
- **PATCH isActive=True is more reliable than RESTORE** — `POST /api/items/items/{id}/restore` may return 200 with `isActive` still false. Use PATCH with `{"isActive": True, "version": version}` instead. On 409 Conflict, retry with `version + 1`.
- No image upload via Items API → use Portal UI drag&drop
- Price lists not manageable via API → create in Portal UI: Settings > Price Lists
- Bearer token on Items → 401 (use X-Api-Key: ten_...)
- Categories/Accounts → Bearer JWT required (not X-Api-Key)
- Use hermes-agent venv Python (`~/.hermes/hermes-agent/venv/bin/python3`), not system python3 (PEP 668)
- Google Sheets cell format cache: write empty string first (RAW), then value (USER_ENTERED) to clear currency formatting

## Reference Files
- `references/bulk-creation-workflow.md` — step-by-step bulk create from source to portal
- `references/stupefy-dedup-sheet-gap.md` — critial bug: dedup skip-list not appended to sheet
- `references/stupefy-20260630.md` — complete session transcript of Jun 30 2026 bulk create (44 items, isActive fix, category assignment)
- `references/stupefy-bulk-import-20260706.md` — fresh portal bulk import of 183 items (name overrides, code conflict resolution, activation)
- `references/pricing-tax-endpoint.md` — price list discovery and price update via PATCH
- `references/spell-commands.md` — spell workflow details
- `references/inventario-stock-count.md` — stock counting pattern
- `references/pet-friendly-classification.md` — pet-safe plant list
- `references/sales-quotations-api.md` — SQ endpoint details and pitfalls
- `references/sales-quotations-and-orders.md` — SO vs SQ comparison, SUPER EXTRA branches, invoice workflow
- `references/business-partners-api.md` — BP CRUD patterns
- `references/discord-bot-hermes-ezy.md` — HERMES_EZY Discord bot setup, token, guilds, channels
- `references/sales-orders-curl-workflow.md` — SO creation via curl with full line fields, required IDs, item UUID drift handling

## Templates
- `templates/quick-start.py` — minimal example: list items with prices
- `templates/bulk-create-items.py` — bulk creation from CSV boilerplate

## Scripts
- `scripts/lumos.py` — portal stock+price → Google Sheet (**check API key is current** and `SHEET_RANGE` points to `INVENTARIO!A1:D300`, not `Sheet1`. As of Jun 30 2026: key=`ten_3HW_...`, range=`INVENTARIO!A1:D300`)
- `scripts/alohomora.py` — portal items+BPs → Airtable (partial)
- `scripts/extract_excel_images.py` — extract embedded images from .xlsx for bulk import