# Spell Commands — Vivero EZY Portal

Automations named as Harry Potter spells. Convention: cast by user saying the spell name.

## Spells (Jun 2026)

| Spell | Direction | Trigger | Script | Status |
|-------|-----------|---------|--------|--------|
| **lumos** | portal → Google Sheet | "lumos" | `scripts/lumos.py` | WORKING |
| **stupefy** | sheet → portal | "stupefy" | manual (no script yet) | WORKING via ad-hoc |
| **alohomora** | portal → Airtable | "alohomora" | `scripts/alohomora.py` | MISSING — rebuild |

## lumos (portal → sheet)

Sync portal stock + SALE_SUPER prices → Google Sheet.

- **Sheet ID**: `1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE`
- **Key field**: `itemStockTotal` (NOT `stockTotal`)
- **Run**: `python3 skills/software-development/ezy-portal-api/scripts/lumos.py`

## stupefy (sheet → portal)

Create/update portal items from Google Sheet rows. No pre-made script — run ad-hoc.

**Current API Key**: `ten_RKKzmvlj3_hAUKwazrTu-EjLLg0v9R367jj8Cui4xt0` (vivero tenant, Jun 29 2026)

**Full workflow**:
1. Read target sheet tab (e.g., `plantas_nuevas`) — columns: CODIGO, NOMBRE, LISTA_PRECIO, PRECIO_USD, STOCK, DESCRIPCION
2. Filter rows where CODIGO is empty (unprocessed)
3. Fetch ALL portal items (`perPage=100`, NOT 200 — 200 returns 400 Bad Request)
   - Build two lookup dicts:
     - `portal_by_name[name.upper().strip()] = itemCode` — exact match
     - `portal_by_norm[norm(name)] = itemCode` — norm(): removes hyphens/quotes, uppercases, collapses spaces
4. For each sheet row without code:
   - Exact name match → exists in portal, skip
   - Normalized match → possible variant, confirm before creating
   - No match → POST to create in portal
5. POST new items (omit `initialUOMs`, use `baseUom: "EA"`)
6. Write codes back to sheet (rewrite CODIGO column for processed rows)

**Key rules**:
- `COST_HACIENDA` ID: `1be181ec-69d9-4661-bebd-e0a09f8ee851`
- `COST_SARA` ID: `607aa5ef-e4a9-4d0b-94dd-6eb04dea83bc`
- `COST_IAN` ID: `31000d32-75f2-467a-b2f8-e5f991aff36c`
- `COST_JARDIN` ID: `ccf36882-505b-420f-89f3-07273f024124`
- Codes: `PL-[NOMBRE_MAYUSCULA_CON_GUIONES]` — code MUST match name exactly
- Prefix: `PL-` plants, `CG-` charges, `CJ-` packaging
**Typo traps** (verify before creating):
- `ESPIRAGUO` → should be `ESPARRAGO` (founding names like `PL-ESPIRAGUO-MEYERI`)
- `PHOTOS MULTI RAMA` → should be `POTHO` (`PL-POTHOS-MULTI-RAMA`)
- `Dracaena Reflexa` / `Lirio` in portal have lowercase names (fix via PATCH by UUID)
- `PALMA ROJA  VR` has double space (fix via PATCH by UUID)

## alohomora (portal → Airtable)

Manual backup. Currently no working script on disk.

- **Airtable base**: `appIQ4f4j6c2bMPlb`
- **Tables**: Items + BusinessPartners
- **Run**: `alohomora update` (intentional no-cron — user-initiated)
- **Backup date field**: `backup_date` with ISO date