---
name: ezy-portal-api
description: "Class-level skill for working with EZY Portal REST API (Items, Categories, Item Groups, UOM Groups, Barcodes, Variants, Stats, Pricing, Sales Quotations). Covers authentication, endpoints, data models, pagination, masking, optimistic concurrency, variant handling, and the vivero tenant workflow."
category: software-development
tags: [ezy, portal, api, rest, items, inventory, pricing, vivero]
metadata:
  hermes:
    tags: [ezy, portal, api, rest, items, inventory, pricing, vivero]
    homepage: https://docs.ezyts.com/en/portal/
---

# EZY Portal API Development Skill

## When to Use
- Building integrations with EZY Portal (Items, Catalog, Pricing, Inventory, Sales Quotations, Business Partners)
- Writing API clients, scripts, or automation against `https://<tenant>.ezyts.com`
- Debugging API responses, pagination, masking, or variant matrix behavior
- Creating/updating items with nested prices, UOMs, barcodes, categories
- Creating or editing Sales Quotations (draft quotes)
- **Always load this skill first** before any EZY Portal work. The skill contains all endpoint URLs, auth patterns, pitfalls, and vivero-specific quirks.

## Authentication

| Endpoint Group | Auth Method | Header |
|----------------|-------------|--------|
| Items, Pricing-Tax, Commerce, Business Partners, Stats | Tenant API Key | `X-Api-Key: ten_...` |
| Accounts, Categories | Bearer JWT | `Authorization: Bearer <jwt>` |

**Critical**: Items and Accounts use DIFFERENT auth on the SAME domain. `X-Api-Key` works for Items but returns 401/404 for Accounts/Categories.

## Base URL
```
https://vivero.ezyts.com
```

## Key Endpoints

### Items
- `GET /api/items/items` — List (filters: `isActive`, `isSellable`, `query`, `sortBy`; expand: `prices`, `itemUoms`)
- `POST /api/items/items` — Create (omit `initialUOMs`, use `baseUom: "EA"`)
- `PATCH /api/items/items/{id}` — Update by UUID (NOT itemCode); requires `version` for optimism
- `GET /api/items/items/{id}` — Full detail
- `GET /api/items/items/by-code/{code}?expand=prices` — Lookup by itemCode (this endpoint returns prices even when list endpoint doesn't)
- `DELETE /api/items/items/{id}` — Soft delete (isActive=false)
- `GET /api/item-groups?perPage=50` — List item groups
- `GET /api/item-classes?perPage=50` — List item classes

### Pricing-Tax
- `GET /api/pricing-tax/price-lists?perPage=50` — List all price lists (paginated response: `{data: [...], hasMore, total}`)

### Sales Quotations
- `GET /api/commerce/sales-quotations?expand=lines` — List (always use expand)
- `POST /api/commerce/sales-quotations` — Create (accepts `lines[]` inline)
- `PATCH /api/commerce/sales-quotations/{id}` — Update draft

### Business Partners
- `GET /api/business-partners/bp` — List (paginated)
- `POST /api/business-partners/bp` — Create (requires `Idempotency-Key` header)

## Pagination
- `page`, `perPage` — max 100 per page (perPage=200 returns 400)
- Response: `total`, `hasMore`
- Always paginate — default 20

## vivero Tenant (Panamá)

### User Preferences
- **Language**: Spanish only. Respond concisely — no explanations, no theory, no "what would you like to do next". Just data, status, next action.
- **Style**: Deliver working artifacts backed by real tool output. Do not stop after writing a plan or stub. Keep executing until the artifact is complete.
- **Data integrity is critical**: If a dedup check produces a skip list, the user expects those items to ALSO end up in the target sheet, not just the portal. Missing data will be caught and called out.
- **Report final counts clearly**: "44 created, 47 skipped, 210 total in sheet" — tabular, not prose.

### Item Code Convention
Pattern: `PL-` + UPPERCASE_NAME_WITH_DASHES. Name and code must match: name `LIRIO GIGANTE` → code `PL-LIRIO-GIGANTE`.

### Stock Field
Use `itemStockTotal` — NOT `stockTotal` (doesn't exist). Use `itemAvailableTotal` for stock excluding pending orders.

### Price List IDs (discovered Jun 30 2026)
```
COST_A&G       629c947f-5edf-441d-9a70-e8d571e5b1d8
COST_IAN       31000d32-75f2-467a-b2f8-e5f991aff36c
COST_JARDIN    ccf36882-505b-420f-89f3-07273f024124
COST_SARA      607aa5ef-e4a9-4d0b-94dd-6eb04dea83bc
COST_EDWIN     02037417-1ac1-45bb-b3b4-df022ff6085d
COST_HACIENDA  1be181ec-69d9-4661-bebd-e0a09f8ee851
COST_ISMAEL    96c2a3fb-380b-41fd-861b-87076ac02bc6
SALE_PUBLIC    0455a655-460f-4a75-b4f7-e1d41b5e6886
SALE_SUPER     e4d473ef-e97e-4258-8391-594b9d0eb9f0
```
Note: COST_EDUARDO does NOT exist as of Jun 30 2026. Must be created via Portal UI. Always verify via `GET /api/pricing-tax/price-lists?perPage=50` each session.

### Item Group & Class (fetch fresh each session, DO NOT hardcode)
Fetch at the START of every session:
```
GET /api/items/item-groups?perPage=50
GET /api/items/item-classes?perPage=50
```
As of Jun 30 2026 (will drift):
- PLANTS group: `b38e9a2d-4951-4d40-9fa3-1357ef0dc631`
- LIVE_PLANT class: `b65da4ee-1f20-45f7-b329-d2b884c7c10d`
**"Item class not found" error means the IDs are stale** — re-fetch immediately.

### Google Sheet
ID: `1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE`
Tabs: INVENTARIO (A=PLANTA, B=FOTO, C=STOCK, D=PRECIO), plantas_nuevas (CODIGO, NOMBRE, LISTA_PRECIO, PRECIO_USD, STOCK, DESCRIPCION)
Token: `~/.hermes/profiles/ezy_portal_expert/google_token.json`

## Cloudflare SSL Workaround
Python `urllib` against `vivero.ezyts.com` gets HTTP 403 (error 1010) without Mozilla User-Agent + SSL context:
```python
import ssl, urllib.request
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
req = urllib.request.Request(url)
req.add_header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36")
```

**Newer API keys (ten_3HW_... onwards) also get 401 from urllib on ALL portal endpoints** even with the Cloudflare workaround. This happens in hermes-agent venv Python (uv-managed) even though curl works fine and the headers are correct. Use `curl` via subprocess for ALL portal API calls with these keys — do not use Python urllib:
```python
import subprocess, json
result = subprocess.run(["curl", "-s", "-H", f"X-Api-Key: {API_KEY}", "-H", "User-Agent: Mozilla/5.0",
    "https://vivero.ezyts.com/api/items/items?perPage=100&page=1"],
    capture_output=True, text=True, timeout=30)
data = json.loads(result.stdout)
```

### Sales Quotations — User Preference (vivero tenant, Jul 2026)

The user manages **3 customer branches** of SUPER EXTRA (same RUC 356-19-77860):
1. **via israel** (CL-0035, id=32249c40-4c89-4fdf-a381-73969dba188d)
2. **los pueblos** (CL-0005, id=a8cea960-d200-4222-8654-6cda0093d6b9)
3. **albrook** (CL-0017, id=db64ad3e-a54c-4f15-b15b-d60dba3917a4)

When creating quotations from Vivero Rose invoices:
- **Reference field** = `"Factura No.{number}"` (e.g., "Factura No.741")
- **Date = expiration date** (validUntil = documentDate)
- **Precio de factura** se pone manualmente (unitPrice), no se usa el precio del portal
- Items que no existen se reemplazan por el más cercano con `description` anotando el nombre original
- Items con "N/C" en la factura se excluyen de la cotización

### Reactivating Items — Batch PATCH

When items needed for a quotation are inactive (`isActive=false`):
1. Fetch ALL items (paginated, active + inactive)
2. Filter inactive: `[i for i in all_items if not i.get("isActive", True)]`
3. PATCH each with `{"isActive": True, "version": version}`
4. On 409 Conflict, retry with `version + 1`

On Jul 1 2026: 57 items reactivated, 0 failures.

**CRITICAL**: Item UUIDs can CHANGE between sessions (re-fetch needed).
**CRITICAL**: `POST /api/items/items/{id}/restore` may return 200 but NOT actually activate the item. Use PATCH instead.

## Spells (Harry Potter CLI convention)

### lumos — Portal → Google Sheet (VERIFIED OK)
Sync portal stock + SALE_SUPER prices → INVENTARIO tab.
- Script: `scripts/lumos.py`
- Run: `~/.hermes/hermes-agent/venv/bin/python3 scripts/lumos.py`
- Normalizes names (strip accents, VR suffix, parentheticals) for matching
- Compacts empty rows automatically
- Updates ALL rows unconditionally (not just empty ones)

### alohomora — Portal → Airtable (PARTIAL)
Backup items + BPs to Airtable base `appIQ4f4j6c2bMPlb`.
- Script: `scripts/alohomora.py`
- Tables: tblTXfSmRyVPV6Tv1 (Items), tblXKTjY4kjgnPdTb (BPs)

### stupefy — Sheet → Portal (ad-hoc)
Bulk create/update items from Google Sheet rows.
- Workflow: `references/spell-commands.md` and `references/bulk-creation-workflow.md`

## Creating Items via POST — Critical Workflow

### Pre-creation: Check for duplicates
1. Fetch ALL active portal items (paginate 100/page)
2. Build `portal_by_name[name.upper().strip()]` and `portal_by_norm[normalize(name)]`
3. For each source row, check exact name match first, then normalized
4. Also check by itemCode if provided

### POST payload
```python
{
    "itemCode": "PL-NEW-ITEM",
    "name": "NEW ITEM NAME",
    "description": "New Item.",
    "itemType": "stock",
    "isStock": True,
    "isPurchasable": True,
    "isSellable": True,
    "baseUom": "EA",
    # OMIT initialUOMs — causes chk_uom_code SQL error
    "itemGroupId": GROUP_ID,       # fetch fresh!
    "itemClassId": CLASS_ID,       # fetch fresh!
    "defaultSalesTaxCategoryId": TAX_ID,
    "defaultPurchaseTaxCategoryId": TAX_ID,
    "prices": [{
        "priceListId": PL_ID,
        "priceListCode": "COST_HACIENDA",
        "price": 20.00,
        "currencyCode": "USD"
    }]
}
```

### Pitfalls
1. **"Item class not found"** → itemGroupId or itemClassId UUIDs are wrong. Fetch fresh from `/api/items/item-groups` and `/api/items/item-classes`.
2. **POST response omits itemCode** → use `id` from response for tracking, not the code field.
3. **Unparseable prices** → sheet values like `"10/20/30"` (range notation) break `float()`. Catch ValueError and default to 0.
4. **DUPLICATE item code** → check existing items by code AND name before creating.
5. **Price masking on success** → `prices: []` in PATCH response doesn't mean write failed. Check `version` increment (1→2 = success).
6. **Barcodes need UOMs first** — POST creates items WITHOUT `itemUoms`. The `/api/items/items/{id}/barcodes` endpoint requires an `itemUomId`. Until UOMs are added via PATCH, barcodes cannot be generated.
7. **Category assignment via PATCH works with API key** — even though `GET /api/categories` requires Bearer JWT, setting `itemCategory` + `tags` on `PATCH /api/items/items/{id}` works with `X-Api-Key`. See `references/vivero-category-mapping.md` for category UUIDs.

### Stupefy Dedup-Sheet Gap (CRITICAL)
When bulk-creating items from a Google Sheet to the portal via stupefy workflow:

1. **Dedup phase** checks portal for existing items → produces `skip_list` (already in portal) and `create_list` (new).
2. **Create phase** sends only `create_list` to the portal API.
3. **Sheet phase** MUST append BOTH `create_list` AND `skip_list` to the target sheet tab.

**The bug**: Only appending `create_list` causes 30-50% of expected plants to vanish from the sheet. The user will notice and call this out.

**The fix**: Always union both lists before writing to the sheet:
```python
all_to_add = [n for _, n, _, _ in create_list] + [n for _, n, _, _ in skip_list]
# Sort, then write to sheet
```

### Post-Creation Fix: isActive + itemGroup (CRITICAL)
Items created via `POST /api/items/items` have `isActive: false` and `itemGroup: null` by default. They WILL NOT appear in the portal's item list view — only in search.

**After bulk creation, ALWAYS patch all new items:**
```python
patch = {"version": version, "isActive": True, "itemGroup": GROUP_ID}
# PATCH /api/items/items/{id} with this payload
```
Without this step, the user will report "no encuentro las bandejas" / "solo en buscar todo".

### Price Lists Endpoint is Paginated
Since Jun 30 2026, `GET /api/pricing-tax/price-lists` returns a **paginated response** `{data: [...], hasMore, total}` — NOT a flat array. Always use `perPage=50` and iterate:
```python
result = curl_get("/api/pricing-tax/price-lists?perPage=50")
for pl in result["data"]:
    price_lists[pl["code"]] = pl["id"]
```

### urllib 401 with Newer API Keys
From `ten_3HW_...` onwards, Python urllib (even from hermes-agent venv with Mozilla UA + SSL workaround) returns **HTTP 401** on ALL portal endpoints. This is NOT the Cloudflare 403 — it's a different failure. Curl from shell works fine with the same headers.

**DO NOT use Python urllib for API calls — use `curl` via subprocess instead.**
See the Authentication section above for the curl subprocess helper.

## Common Pitfalls (condensed)
- `itemStockTotal` includes items on order → use `itemAvailableTotal` for sellable stock
- PATCH requires UUID, not itemCode → always fetch `/by-code/{code}` first
- PATCH with `prices` replaces entire array, doesn't merge
- Missing `version` on PATCH → 409 Conflict
- `expand=prices` on list endpoint returns items WITHOUT prices key; use `/by-code/{code}?expand=prices` instead
- **Sales Quotations: `lineNumber` is REQUIRED** on every line — sequential integers starting from 1. All lines with `lineNumber: 0` cause `"duplicate lineNumber values: [0]"` error.
- **Sales Quotations: All line fields required** — `itemId`, `itemCode`, `itemName`, `warehouseId/Code/Name`, `taxCategoryId/Code/Name`, `uomCode` — even `unitOfMeasure`. Missing any causes per-line validation failure.
- **Sales Quotations: `expand=lines` may return empty** in subsequent GET even when lines were saved — trust `grandTotal` as ground truth.
- **Item UUIDs drift between sessions** — Always re-fetch via `/api/items/items/by-code/{code}` at session start. Hardcoded UUIDs from a previous session fail with `"Item: item not found"`.
- **PATCH isActive=True is more reliable than RESTORE** — `POST /api/items/items/{id}/restore` may return 200 with `isActive` still false. Use PATCH with `{"isActive": True, "version": version}` instead. On 409 Conflict, retry with `version + 1`.
- No image upload via Items API → use Portal UI drag&drop
- Price lists not manageable via API → create in Portal UI: Settings > Price Lists
- Bearer token on Items → 401 (use X-Api-Key: ten_...)
- Categories/Accounts → Bearer JWT required (not X-Api-Key)
- Use hermes-agent venv Python (`~/.hermes/hermes-agent/venv/bin/python3`), not system python3 (PEP 668)
- Google Sheets cell format cache: write empty string first (RAW), then value (USER_ENTERED) to clear currency formatting

## Reference Files
- `references/bulk-creation-workflow.md` — step-by-step bulk create from source to portal
- `references/stupefy-dedup-sheet-gap.md` — critial bug: dedup skip-list not appended to sheet
- `references/stupefy-20260630.md` — complete session transcript of Jun 30 2026 bulk create (44 items, isActive fix, category assignment)
- `references/pricing-tax-endpoint.md` — price list discovery and price update via PATCH
- `references/spell-commands.md` — spell workflow details
- `references/inventario-stock-count.md` — stock counting pattern
- `references/pet-friendly-classification.md` — pet-safe plant list
- `references/sales-quotations-api.md` — SQ endpoint details and pitfalls
- `references/business-partners-api.md` — BP CRUD patterns

## Templates
- `templates/quick-start.py` — minimal example: list items with prices
- `templates/bulk-create-items.py` — bulk creation from CSV boilerplate

## Scripts
- `scripts/lumos.py` — portal stock+price → Google Sheet (**check API key is current** and `SHEET_RANGE` points to `INVENTARIO!A1:D300`, not `Sheet1`. As of Jun 30 2026: key=`ten_3HW_...`, range=`INVENTARIO!A1:D300`)
- `scripts/alohomora.py` — portal items+BPs → Airtable (partial)
- `scripts/extract_excel_images.py` — extract embedded images from .xlsx for bulk import