#!/usr/bin/env python3
"""
lumos — sync EZY Portal stock + price → Google Sheet
Harry Potter spell: light to reveal truth

Usage:
  python3 scripts/lumos.py

Requires:
  - X-Api-Key: ten_...  (set in KEY below, or export EZY_KEY)
  - Google Sheets API credentials (google_api.py skill)
  - Sheet ID: 1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE
"""

import json, os, ssl, subprocess, re, unicodedata, urllib.request

# === CONFIG ===
KEY = os.environ.get("EZY_KEY", "ten_3HW_frAuoKDYRyuzUfzUEDzva-ypPuzL9G3sljmBTWc")
SHEET_ID = "1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE"
SHEET_RANGE = "INVENTARIO!A1:D300"
PRICE_LIST = "SALE_SUPER"
PORTAL_URL = "https://vivero.ezyts.com"
# ==============

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE


def fetch_portal_items():
    items = {}
    page = 1
    while True:
        url = f"{PORTAL_URL}/api/items/items?isActive=true&expand=prices,itemUoms&perPage=100&page={page}"
        req = urllib.request.Request(url)
        req.add_header("X-Api-Key", KEY)
        req.add_header("User-Agent", "Mozilla/5.0")
        with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
            data = json.loads(resp.read())
        for d in data["data"]:
            price = ""
            for p in d.get("prices", []):
                if p.get("priceListCode") == PRICE_LIST and not p.get("masked"):
                    price = str(p.get("price", ""))
                    break
            items[d["name"]] = {"stock": d.get("itemStockTotal", 0), "price": price}
        if not data.get("hasMore"):
            break
        page += 1
    return items


def fetch_sheet():
    result = subprocess.run([
        "/Users/abrahamkortovich/.hermes/hermes-agent/venv/bin/python3",
        "/Users/abrahamkortovich/.hermes/profiles/ezy_portal_expert/skills/productivity/google-workspace/scripts/google_api.py",
        "sheets", "get", SHEET_ID, SHEET_RANGE,
    ], capture_output=True, text=True, timeout=60)
    return json.loads(result.stdout)


def normalize(name):
    n = name.upper()
    n = unicodedata.normalize("NFD", n)
    n = re.sub(r"[\u0300-\u036f]", "", n)
    n = re.sub(r"[\(\)\[\]].*", "", n)
    n = re.sub(r"\s+", " ", n).strip()
    n = re.sub(r"\s*(VR|EN POTE.*|BOLSA.*|POTE.*|PDB.*|MCL.*|VCG.*|19Z.*|GEOTEXTIL.*)$", "", n)
    return n.strip()


def is_empty_row(row):
    if not row:
        return True
    return all(str(c).strip() == "" for c in row)


def write_sheet(data):
    result = subprocess.run([
        "/Users/abrahamkortovich/.hermes/hermes-agent/venv/bin/python3",
        "/Users/abrahamkortovich/.hermes/profiles/ezy_portal_expert/skills/productivity/google-workspace/scripts/google_api.py",
        "sheets", "update", SHEET_ID, f"INVENTARIO!A1:D{len(data)}",
        "--values", json.dumps(data),
    ], capture_output=True, text=True, timeout=60)
    return result


def main():
    print("Fetching portal items...")
    portal_items = fetch_portal_items()
    print(f"  {len(portal_items)} items")

    print("Fetching sheet...")
    sheet_data = fetch_sheet()
    print(f"  {len(sheet_data)} rows incl. header")

    portal_norm = {normalize(n): (n, d) for n, d in portal_items.items()}

    # Compact empty rows
    header = sheet_data[0]
    rows = sheet_data[1:]
    empty_count = sum(1 for r in rows if is_empty_row(r))
    if empty_count:
        print(f"  Compacting {empty_count} empty row(s)...")
        rows = [r for r in rows if not is_empty_row(r)]
        sheet_data = [header] + rows

    # Find and apply updates
    updates = 0
    for row in sheet_data[1:]:
        if len(row) < 1 or not row[0] or row[0].strip().upper() in ("PLANTA", ""):
            continue
        sheet_name = row[0].strip()
        sheet_stock = str(row[2]).strip() if len(row) > 2 else ""
        norm = normalize(sheet_name)
        if norm not in portal_norm:
            continue
        _, pdata = portal_norm[norm]
        portal_stock = str(pdata["stock"])
        portal_price = pdata["price"] or ""

        changed = False
        if str(sheet_stock) != portal_stock:
            row[2] = portal_stock
            changed = True
        if portal_price and len(row) < 4:
            row.append(portal_price)
        elif portal_price and row[3] != portal_price:
            row[3] = portal_price
            changed = True

        if changed:
            updates += 1

    if updates:
        print(f"Writing {updates} update(s)...")
        write_sheet(sheet_data)
    else:
        print("No updates needed — sync OK")


if __name__ == "__main__":
    main()