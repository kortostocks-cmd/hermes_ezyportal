---
name: vivero-google-sheets
description: "Google Sheets access for vivero.ezyts.com — automated OAuth + read/write 'plantas_nuevas' tab (ID: 1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE)"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
required_credential_files:
  - path: google_token.json
    description: "Google OAuth2 token (auto-managed by setup)"
  - path: google_client_secret.json
    description: "Google OAuth2 client credentials (Desktop app)"
metadata:
  hermes:
    tags: [Google, Sheets, vivero, plants, OAuth]
    homepage: https://github.com/NousResearch/hermes-agent
    related_skills: [google-workspace]
---

# Vivero Google Sheets

Skill dedicado al Google Sheet del vivero (`1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE`).
Maneja OAuth automático (token en `~/.hermes/profiles/ezy_portal_expert/google_token.json`)
y expone CLI simple para leer/escribir la pestaña `plantas_nuevas`.

## Configuración (una sola vez)

```bash
# 1. Verificar si ya está autenticado
VSETUP --check

# 2. Si NO_AUTHENTICATED: guardar client_secret.json y correr
VSETUP --client-secret /ruta/a/client_secret.json

# 3. Obtener URL de autorización
VSETUP --auth-url

# 4. Abrir URL en navegador, autorizar TODOS los scopes, copiar URL final (http://localhost/?code=...)
# 5. Intercambiar código
VSETUP --auth-code "URL_COMPLETA_DEL_NAVEGADOR"

# 6. Verificar
VSETUP --check
# Debe salir: AUTHENTICATED: Token valid
```

Alias recomendados (agregar a `~/.zshrc` o `~/.bashrc`):
```bash
VSETUP="python ~/.hermes/profiles/ezy_portal_expert/skills/productivity/vivero-google-sheets/scripts/setup.py"
VAPI="python ~/.hermes/profiles/ezy_portal_expert/skills/productivity/vivero-google-sheets/scripts/sheets_api.py"
```

## Uso diario

```bash
# Leer plantas_nuevas (tabla completa)
$VAPI read plantas_nuevas

# Leer rango específico
$VAPI read plantas_nuevas A1:F50

# Escribir/actualizar filas (append)
$VAPI append plantas_nuevas '[[\"PL-NUEVO\",\"NUEVA PLANTA\",\"COST_HACIENDA\",\"15\",\"\",\"Desc\"]]'

# Sobrescribir rango
$VAPI write plantas_nuevas A2 '[[\"PL-NUEVO\",\"NUEVA PLANTA\",\"COST_HACIENDA\",\"15\",\"\",\"Desc\"]]'

# Crear nueva pestaña (batchUpdate addSheet)
$VAPI add-sheet nombre_pestaña
```

## Estructura de `plantas_nuevas`

| Columna | Ejemplo | Notas |
|---------|---------|-------|
| CODIGO | PL-ANTORCHA | Prefijo `PL-` |
| NOMBRE | ANTORCHA | Nombre comercial |
| LISTA_PRECIO | COST_HACIENDA | COST_HACIENDA / COST_SARA |
| PRECIO_USD | 20 | Número (string en sheet) |
| STOCK | (vacío) | Opcional |
| DESCRIPCION | (vacío) | Opcional |

## Scripts

- `scripts/setup.py` — OAuth setup (wrapper del google-workspace setup.py apuntando a este profile)
- `scripts/sheets_api.py` — CLI simple read/append/write/add-sheet para este sheet ID

## Workflow LUMOS — Normalización de plantas_nuevas

Cuando el usuario dice "LUMOS" (o "lumos"), ejecutar:

1. Verificar OAuth token, refrescar si expirado (usar venv de Hermes directamente)
2. Leer pestaña `plantas_nuevas` completa
3. Para cada fila:
   - Normalizar NOMBRE a UPPERCASE
   - Si CODIGO está vacío o incorrecto: generar `PL-` + slugify(nombre)
   - Slugify usa NFKD normalisation (Ñ→N, acentos quitados), UPPERCASE, regex `[^A-Z0-9]+`→`-`
4. Aplicar batchUpdate con `valueInputOption: USER_ENTERED`
5. Verificar duplicados vs pestaña INVENTARIO (comparar nombres normalizados)
6. Reportar resultado al usuario

Ver `references/plantas-nuevas-normalizacion.md` para detalles de slugificación y detección de duplicados.

### Eliminación de filas duplicadas en plantas_nuevas

Cuando filas duplicadas tienen el mismo nombre y lista de precio (ej: "SANSEVIERIA R" ×2 ambas COST_EDWIN), borrar con `deleteDimension`. Las filas se borran **de abajo hacia arriba** para no alterar índices:

```python
requests = [
    {
        'deleteDimension': {
            'range': {
                'sheetId': 0,      # ID de la primera sheet (generalmente 0)
                'dimension': 'ROWS',
                'startIndex': row_index,    # 0-indexed, fila sheet a borrar
                'endIndex': row_index + 1
            }
        }
    }
]
body = {'requests': requests}
svc.spreadsheets().batchUpdate(spreadsheetId=SID, body=body).execute()
```

**Regla**: solo borrar duplicados idénticos (misma lista, mismo precio, sin diferenciación en nombre). Si tienen diferente lista de precio (ej: CORDILINIA COST_HACIENDA vs CORDILINIA COST_ISMAEL), conservar ambas.

### Verificación final

Después de limpiar y normalizar, verificar contra la pestaña INVENTARIO por nombre normalizado (NFKD + ASCII + UPPERCASE + `re.sub(r'[^A-Z0-9]', '', s)`) para asegurar que son plantas realmente nuevas, no existentes con nombre diferente.

## Reglas

1. **Nunca** hacer write/append sin confirmar con el usuario (mostrar preview).
2. Token se renueva solo; si falla → `VSETUP --revoke` y repetir pasos 2-5.
3. Sheet ID fijo: `1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE` (no cambiar sin confirmar).
4. **Nombres en mayúsculas**: toda fila nueva debe tener NOMBRE en UPPERCASE. Si encuentras minúsculas, corregir antes de procesar.
5. **Códigos según nombre**: el código debe generarse con `PL-` + nombre normalizado (sin acentos, Ñ→N, espacios→guiones). No usar códigos arbitrarios.
6. **Duplicados en el sheet**: antes de crear items, verificar nombres repetidos dentro del mismo sheet y eliminarlos.

## Pitfalls

### PEP 668: pip bloqueado en macOS

macOS 12.7.6+ tiene PEP 668 activo — `pip install` falla incluso con `--user`. Los scripts `setup.py` y `sheets_api.py` fallan si intentan instalar dependencias.

**Fix**: usar el venv de Hermes directamente:

```bash
~/.hermes/hermes-agent/venv/bin/python3 -c "
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

creds = Credentials.from_authorized_user_file(
    '~/.hermes/profiles/ezy_portal_expert/google_token.json',
    ['https://www.googleapis.com/auth/spreadsheets']
)
if creds.expired and creds.refresh_token:
    creds.refresh(Request())
    import json
    with open('~/.hermes/profiles/ezy_portal_expert/google_token.json', 'w') as f:
        json.dump(json.loads(creds.to_json()), f)
    print('Token refreshed OK')
service = build('sheets', 'v4', credentials=creds)
result = service.spreadsheets().values().get(...)
```

### Token OAuth expirado con refresh_token disponible

El token Google expira cada hora. Si `setup.py --check` falla pero el token tiene `refresh_token`, se puede refrescar programáticamente sin re-autenticar. El truco es usar `Request()` de `google.auth.transport.requests` — no requiere browser.