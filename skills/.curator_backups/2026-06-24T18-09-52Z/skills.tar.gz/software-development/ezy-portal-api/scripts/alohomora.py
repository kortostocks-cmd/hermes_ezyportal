#!/usr/bin/env python3
"""
alohomora — EZY Portal backup to Airtable

Usage:
    python3 alohomora.py <portal_api_key>

Example:
    python3 alohomora.py ten_VUIZ7CfBTQ3x02H4MhDrFnRjXDRFPGlBYHYCUL6et3g
"""
import sys, json, ssl, urllib.request, time
from datetime import date

# ── Config ───────────────────────────────────────────────────────────────────
TENANT_URL  = "https://vivero.ezyts.com"
BASE_ID     = "appIQ4f4j6c2bMPlb"
TBL_ITEMS   = "tblTXfSmRyVPV6Tv1"
TBL_BP      = "tblXKTjY4kjgnPdTb"
AIRTABLE_KEY = "patozWFMZn8GCrcQZ.8a5a54ace302fe272c9905e94c93889ba864514a562d5613f15a799d78c815bb"
TODAY_ISO  = date.today().isoformat()  # 2025-06-24
TODAY_FMT  = date.today().strftime("%b %d")  # Jun 24

SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE

# ── Portal fetch ──────────────────────────────────────────────────────────────
def portal_get(path):
    url = f"{TENANT_URL}{path}"
    req = urllib.request.Request(url)
    req.add_header("X-Api-Key", sys.argv[1])
    req.add_header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36")
    with urllib.request.urlopen(req, timeout=30, context=SSL_CTX) as r:
        return json.loads(r.read())

def fetch_all_items():
    items, page = [], 1
    while True:
        d = portal_get(f"/api/items/items?perPage=100&page={page}&isActive=true&expand=prices")
        items.extend(d.get("data", []))
        if not d.get("hasMore"):
            break
        page += 1
    return items

def fetch_all_bp():
    bps, page = [], 1
    while True:
        d = portal_get(f"/api/business-partners/bp?page={page}&perPage=100")
        bps.extend(d.get("data", []))
        if not d.get("hasMore"):
            break
        page += 1
    return bps

# ── Airtable push ─────────────────────────────────────────────────────────────
def at_patch(table_id, records):
    url = f"https://api.airtable.com/v0/{BASE_ID}/{table_id}"
    headers = {
        "Authorization": f"Bearer {AIRTABLE_KEY}",
        "Content-Type": "application/json"
    }
    all_results = []
    for i in range(0, len(records), 10):
        batch = records[i:i+10]
        payload = json.dumps({"records": [{"fields": f} for f in batch]}).encode()
        req = urllib.request.Request(url, data=payload, headers=headers)
        with urllib.request.urlopen(req, timeout=60) as r:
            all_results.extend(json.loads(r.read()).get("records", []))
        if i + 10 < len(records):
            time.sleep(0.25)
    return all_results

# ── Main ──────────────────────────────────────────────────────────────────────
print(f"[alohomora] {TODAY_FMT} — Iniciando backup...")
print(f"[alohomora] Portal: {TENANT_URL}")

items = fetch_all_items()
print(f"[alohomora] {len(items)} items obtenidos")

bps = fetch_all_bp()
print(f"[alohomora] {len(bps)} business partners obtenidos")

# Build item records
item_records = []
for it in items:
    fields = {
        "itemCode":    it.get("itemCode", ""),
        "name":        it.get("name", ""),
        "stock":       it.get("itemStockTotal", 0) or 0,
        "isActive":    it.get("isActive", True),
        "backup_date": TODAY_ISO,
    }
    prices = it.get("prices", []) or []
    price_row = next((p for p in prices if p.get("priceListCode") == "SALE_SUPER"), None)
    if price_row and price_row.get("price") is not None:
        fields["price"] = price_row["price"]
    item_records.append(fields)

# Build BP records
bp_records = []
for bp in bps:
    fields = {
        "code":        bp.get("code", ""),
        "name":        bp.get("name", ""),
        "backup_date": TODAY_ISO,
    }
    if bp.get("email"):
        fields["email"] = bp["email"]
    if bp.get("phone"):
        fields["phone"] = bp["phone"]
    bp_records.append(fields)

# Push
print(f"[alohomora] Subiendo {len(item_records)} items a Airtable...")
try:
    at_patch(TBL_ITEMS, item_records)
    print(f"[alohomora] Items — OK")
except Exception as e:
    print(f"[alohomora] Items — ERROR: {e}")

print(f"[alohomora] Subiendo {len(bp_records)} BPs a Airtable...")
try:
    at_patch(TBL_BP, bp_records)
    print(f"[alohomora] BPs — OK")
except Exception as e:
    print(f"[alohomora] BPs — ERROR: {e}")

print(f"\n✅ alohomora update — {TODAY_FMT}")
print(f"   Items: {len(item_records)} | BPs: {len(bp_records)}")