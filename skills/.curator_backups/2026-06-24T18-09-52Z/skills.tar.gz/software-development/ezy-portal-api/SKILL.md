---
name: ezy-portal-api
description: Class-level skill for working with EZY Portal REST API (Items, Categories, Item Groups, UOM Groups, Barcodes, Variants, Stats). Covers authentication, endpoints, data models, pagination, masking, optimistic concurrency, and variant handling.
category: software-development
tags: [ezy, portal, api, rest, swagger, openapi, items, inventory, pricing]
---

# EZY Portal API Development Skill

## When to Use
- Building integrations with EZY Portal (Items, Catalog, Pricing, Inventory)
- Writing API clients, scripts, or automation against `https://app.portal.net/api/...`
- Debugging API responses, pagination, masking, or variant matrix behavior
- Creating/updating items with nested UOMs, barcodes, categories, prices

## Core Knowledge (from `mi-cerebro/hermes/knowledge/ezy_portal/ezy_rules.md`)

### Authentication
| Scheme | Header | Notes |
|--------|--------|-------|
| BearerAuth | `Authorization: Bearer <jwt>` | Most endpoints |
| CookieAuth | Session cookie | `/stats`, `/stats/quality` only |
| X-Api-Key | `X-Api-Key: ten_...` | Tenant API Keys (Superuser only, generated in Portal UI → Settings → API Keys) |
| ApiKey | `Authorization: ApiKey <key>` | EZY Integrations service (separate domain) |

### Authentication by Endpoint Group (Critical Distinction)

| Endpoint Group | Auth Method | Header | Notes |
|----------------|-------------|--------|-------|
| **Items** (`/api/items/...`) | Tenant API Key | `X-Api-Key: ten_...` | Superuser-generated in Portal UI → Settings → API Keys |
| **Stats/Quality** (`/api/items/stats*`) | **Tenant API Key** | `X-Api-Key: ten_...` | **Works** despite docs saying CookieAuth |
| **Business Partners** (`/api/business-partners/bp*`, `/api/business-partners/contacts`) | Tenant API Key | `X-Api-Key: ten_...` | **Works** — same as Items module |
| **Accounts/Clients** (`/api/accounts`) | **Bearer JWT** | `Authorization: Bearer *** | User login token — X-Api-Key returns **401** |
| **Categories** (`/api/categories*`) | **Bearer JWT** | `Authorization: Bearer *** | User login token — X-Api-Key returns 404/401 |
| **Integrations** (`/api/...` on integrations domain) | ApiKey | `Authorization: ApiKey <key>` | Different service — see EZY Integrations docs |

**Critical**: The Items API and Accounts API use **different authentication schemes** on the same tenant domain. Items work with `X-Api-Key: ten_...`; Accounts require a user Bearer token from login.

### Base URL
```
https://app.portal.net/api/items/items      # via gateway (generic)
https://<tenant>.ezyts.com/api/items/items  # TENANT-SPECIFIC (e.g., https://vivero.ezyts.com)
```

**Important**: Production tenants use their own subdomain on `ezyts.com`. Always use the tenant's actual portal URL.

### Key Endpoints (36 total)

#### Items (14)
- `GET /api/items/items` — List with extensive filters, pagination, sorting
- `POST /api/items/items` — Create with nested `initialUOMs`, `initialBarcodes`, `initialCategories`, `prices`
- `GET /api/items/items/{id}` — Full detail (UOMs, barcodes, prices, categories, variantMatrix)
- `PATCH /api/items/items/{id}` — Update (excludes stock total); `uoms[]` uses `ItemUOMInput` for create/update/delete in one request
- `DELETE /api/items/items/{id}` — Soft delete (`isActive=false`)
- `GET /api/items/items/by-code/{code}` — Lookup by itemCode
- `GET /api/items/items/select` — Lightweight for dropdowns; `variantRole=parents|children|all`
- `GET /api/items/items/{id}/barcodes` — List/add barcodes (requires `itemUomId`)
- `POST /api/items/items/{id}/restore` — Restore soft-deleted (superuser)
- `GET /api/items/items/{id}/uoms` — List/add UOMs
- `GET /api/items/stats` — Dashboard stats
- `GET /api/items/stats/quality` — Data quality metrics
- `GET /api/items/trash/items` — Soft-deleted list (superuser)

#### Price Lists — **NOT MANAGEABLE VIA API**
- Price lists exist in separate `pricing-tax` service
- **Must be created in Portal UI**: Settings → Price Lists → New
- API only references them by `priceListCode` string on items

#### Categories (6)
- `GET/POST /api/categories` — Hierarchical, filter `active`
- `POST /api/categories/mappings` — Associate item ↔ category

#### Item Groups / UOM Groups / Barcodes
- Standard CRUD on `/item-groups`, `/uom-groups`, `/barcodes`

#### Business Partners
- `GET /api/business-partners/bp` — List all (paginated)
- `GET /api/business-partners/bp/{id}` — Single BP
- `POST /api/business-partners/bp` — Create (requires `Idempotency-Key` header)

### Critical Patterns

**ItemCode Format Convention (vivero tenant)**
- Pattern: `PL-` + UPPERCASE_NAME_WITH_DASHES
- Examples: `PL-AGAVE-EN-POTE`, `PL-AGLONEMAS`, `PL-ALBAHACA`

**Price Masking**
- Every price row has `masked: boolean`
- `masked=true` → `price=null`
- Tenant API key lacks price permissions → `prices: []` (empty array)

**Optimistic Concurrency**
- `version` (integer) on Item — must match on PATCH or 409 conflict

**Pagination**
- Standard: `page`, `perPage` (max 100). Response: `total`, `hasMore`
- **Always paginate** — default 20, easy to miss items

**PATCH field names (discovered by trial)**
- `itemGroup` (string UUID) — NOT `itemGroupId`
- `itemClassId` (string UUID) — IS `itemClassId`
- `primaryImageStorageKey` — empty string `""` clears it

**Image Handling**
- Items store only a reference: `primaryImageStorageKey`
- **No upload endpoint in Items API** — must use Portal UI drag&drop or direct storage API

**urllib blocked by Cloudflare** → `HTTP Error 403: error code 1010`
The portal blocks bare Python UA strings. In any Python fetch script:
```python
import ssl, urllib.request
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
req = urllib.request.Request(url)
req.add_header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
    data = json.loads(resp.read())
```
`curl` from shell works fine without these headers.

**Categories endpoint with tenant API key** → Returns 404/401. Requires **Bearer JWT** from user browser session.

### Google Sheets Sync (lumos / vivero Sheet)

**Sheet ID (vivero)**: `1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE`

#### Cloudflare SSL Workaround

Python `urllib` against `vivero.ezyts.com` gets **HTTP 403 error 1010** from Cloudflare without a realistic User-Agent:

```python
import ssl, urllib.request
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
req = urllib.request.Request(url)
req.add_header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36")
with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
    data = json.loads(resp.read())
```

**CRITICAL**: Portal stock field is `itemStockTotal` (NOT `stockTotal`). Using the wrong field gives silent 0.

#### Running google_api.py

The `google_api.py` script requires the hermes-agent venv Python — do NOT use system python3:

```
/Users/abrahamkortovich/.hermes/hermes-agent/venv/bin/python3 \
  /Users/abrahamkortovich/.hermes/profiles/ezy_portal_expert/skills/productivity/google-workspace/scripts/google_api.py \
  sheets get <sheet_id> Sheet1!A1:D200
```

#### lumos Verification (Jun 24 2026 — VERIFIED OK)

Workflow used to verify sheet vs portal:
1. Fetch portal items page 1+2 with `expand=prices,itemUoms&isActive=true` — read `itemStockTotal` per item
2. Fetch sheet via google_api.py with `Sheet1!A1:D200`
3. Normalize names: strip accents, uppercase, remove `()[]` and VR suffix
4. Compare by normalized name — stock desfasado = `stock_sheet != itemStockTotal`
5. Clear stale rows: `sheets update <sheet_id> Sheet1!A{row}:D{row} --values '[["","","",""]]'`

**Result Jun 24**: 121 portal items, 121 sheet rows, 0 stock mismatches. One stale row cleared (`APIO POTE 140" PROMOCION HASTA 14 DE JUNIO`).

#### Sheet Update Logic — Update ALL Matched Rows

The `lumos.py` script originally only updated rows where column C (STOCK) was empty. This missed desynchronized data. The script was fixed to **update all matched rows unconditionally**. If you write new sheet-sync logic, do NOT gate updates on "if cell is empty" — always write the current value.

#### Name Mismatch: FITTONIA vs FITONIA

The portal has **"FITONIA ROJA VR"** (single T) but imports from Excel may create items with **"FITTONIA ROJA VR"** (double T). Run `lumos` after any bulk import to re-sync by correct name, and fix typos directly with `sheets update Sheet1!A{row}`.

### Harry Potter Spells Convention

Automations that sync EZY Portal data to external systems are named as spells.

**`lumos`** — Verified OK Jun 24 2026. Sync portal stock → Google Sheet.
- **Sheet ID:** `1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE`
- **Columns:** A=PLANTA, B=FOTO, C=STOCK, D=PRECIO
- **Requires:** Google Sheets API credentials configured (`google_api.py` skill)
- **Script status**: Needs rebuilding — not on disk. Last verified manually via execute_code.

**`alohomora`** — In progress (Jun 24 2026). Backup portal items + business partners → Airtable.
- **Base**: `appIQ4f4j6c2bMPlb` ("Vivero Backup")
- **Tables**: Items (`tblTXfSmRyVPV6Tv1`), BusinessPartners (`tblXKTjY4kjgnPdTb`)
- **Command**: `alohomora update` (manual, user-initiated)
- **Backup_date format**: ISO `YYYY-MM-DD`
- **Status**: Script incomplete — awaiting Airtable PAT from user. Partial script at `/tmp/alohomora.py`.
### `itemStockTotal` (not `stockTotal`)

The API response for items contains `itemStockTotal` (integer) — **NOT `stockTotal`**. `stockTotal` does not exist in the response and silently returns `None` if used. Also available: `itemAvailableTotal`, `itemReservedTotal`, `itemOnOrderTotal`.

Example from `PL-AJI-BOLITA` (vivero tenant, 2026-06-24):
```python
item = api_get(f"/api/items/items?expand=itemUoms&isActive=true")['data'][0]
item['itemStockTotal']   # → 72  (correct — USE THIS)
item['stockTotal']        # → None (wrong — key does not exist)
```

This caused a 44-item "desfase" report before the correct field was identified.

### Cloudflare SSL Workaround (Python)

Cloudflare blocks Python's default urllib User-Agent with HTTP 403 (error 1010). To fetch from vivero.ezyts.com via Python:

```python
import ssl, urllib.request
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
req = urllib.request.Request(url)
req.add_header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36")
with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
    data = json.loads(resp.read())
```

### Google Sheets Operations

Sheet ID: `1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE`. Read via `sheets get`, write/update via `sheets update`. Values must be 2D arrays even for single cells: `[[value]]`. No `batch-update` action — use `sheets update` for individual ranges. Clear with `sheets clear`.

### Scripts (on disk)

- `scripts/extract_excel_images.py` — Extract embedded images from Excel .xlsx for bulk import.
- `scripts/lumos.py` — **MISSING ON DISK** — must be rebuilt. Sync portal stock → Google Sheet. Handles pagination (fetch ALL pages via `hasMore`, NOT fixed `[1,2]`), SSL fix, realistic User-Agent, normalize name matching. Updates ALL matched rows in column C. Run: `venv/bin/python3 ezy-portal-api/scripts/lumos.py <api_key> <sheet_id>`.
- `scripts/alohomora.py` — **MISSING ON DISK** — must be rebuilt. Backup portal items + business partners → Airtable. Handles pagination, SSL fix, Airtable upsert in batches of 10. Upserts by `itemCode` (Items) or `code` (BusinessPartners). See `references/alohomora-backup.md` for design.

**Aspirational links** (not on disk — scripts need to be rebuilt):
- `scripts/lumos.py`
- `scripts/alohomora.py`
## References
- `references/lumos-check-20260624.md` — Portal vs Sheet comparison run 2026-06-24; working verification script at `/tmp/check_lumos.py`; action items for stale-row cleanup and lumos.py rebuild
- `references/ezy-rules-summary.md` — Condensed endpoint + model reference
- `references/vivero-sheet-sync.md` — Sheet sync: columns, `google_api.py` usage, image matching, spell convention

## Templates
- `templates/quick-start.py` — Minimal example: list items with prices
- `templates/bulk-create-items.py` — Bulk creation from CSV

## Scripts
**lumos.py** (MISSING on disk — needs rebuild). Harry Potter spell: sync portal stock → Google Sheet. ⚠️ The SKILL.md previously claimed this script existed; it does not on disk. The script `/tmp/check_lumos.py` was written during session 2026-06-24 and can serve as a reference for the rebuild. See `references/lumos-check-20260624.md`.
- `scripts/extract_excel_images.py` — Extract embedded images from Excel .xlsx for bulk import.

## Spells (Harry Potter CLI convention — vivero tenant)
- **lumos** — Verified OK Jun 24 2026. Sync portal stock → Google Sheet. Script MISSING on disk — must be rebuilt. See `references/vivero-sheet-sync.md`.
- **alohomora** — In progress. Backup portal items + business partners → Airtable. Script incomplete — awaiting Airtable PAT. See `references/alohomora-backup.md`.

## Common Pitfalls
1. **Forgetting `expand=prices`** → prices array missing entirely
2. **Missing `version` on PATCH** → 409 conflict
3. **Not paginating** → default 20, easy to miss data
4. **Using `itemGroupId` in PATCH** → field is `itemGroup` (string UUID)
5. **Price Lists not manageable via API** → must use Portal UI
6. **No image upload endpoint** → must use Portal UI or direct storage API
7. **`/internal/items/{id}/stock` serves HTML, not API** → use Portal UI for stock adjustments
8. **urllib blocked by Cloudflare** → add Chrome User-Agent + SSL context (see pattern above)
9. **lumos API key not in env** → not stored anywhere; ask user for `ten_...` key directly
10. **Google Sheets `sheets update` wrong dimensions** → 2D array required: `[[val], [val], ...]`
11. **Sheet names from import may have typos** → e.g., "FITTONIA" (double-T) vs portal "FITONIA". Fix cell directly, don't rename files.
12. **`pageSize` vs `maxRecords` in Airtable reads** → `maxRecords` does NOT paginate (returns `offset=null` always). Use `pageSize=100` which returns proper offset cursor. Affected both alohomora and manual verification — caused 22 items to appear missing.
13. **`itemStockTotal` vs `stockTotal`** → the API returns `itemStockTotal`. Using `stockTotal` silently returns `None` and causes stock comparisons to report 0. Always use `itemStockTotal`.