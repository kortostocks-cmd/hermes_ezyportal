# lumos check — session 2026-06-24

## What was done

Compared EZY Portal (121 items, 2 pages) vs Google Sheet `1jYZn3Kd8nIMlRxcQ1nC3K6C3pIzpGPemsO8bc4qG3NE` (122 rows).

**Initial false alarm**: 44 stocks showed as "desfase" because the comparison script used `item.get('stockTotal')` which doesn't exist — returned `None` for everything.

**Root cause**: API field is `itemStockTotal`, not `stockTotal`.

**Results after fix**:
- Items in portal not in sheet: **0**
- Stocks desfasados: **0** (all matched after correct field used)
- Items in sheet not in portal: **1** — `APIO POTE 140" PROMOCION HASTA 14 DE JUNIO` (stale row, promo expired)

## Verification script

Working script at `/tmp/check_lumos.py` — uses `itemStockTotal`, paginates pages 1+2, normalizes names, and reports all three mismatch categories.

**Key pattern** (Cloudflare SSL bypass + realistic UA):
```python
import ssl, urllib.request
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
req = urllib.request.Request(url)
req.add_header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36")
with urllib.request.urlopen(req, timeout=30, context=ctx) as resp:
    data = json.loads(resp.read())
```

## Sheet access

```bash
/Users/abrahamkortovich/.hermes/hermes-agent/venv/bin/python3 \
  /Users/abrahamkortovich/.hermes/profiles/ezy_portal_expert/skills/productivity/google-workspace/scripts/google_api.py \
  sheets get <SHEET_ID> Sheet1!A1:D200
```

NOT via `hermes sheets` (that subcommand doesn't exist on this CLI).

## Action items

- [ ] Remove stale row: `APIO POTE 140" PROMOCION HASTA 14 DE JUNIO` from Sheet1
- [ ] Rebuild `lumos.py` (MISSING on disk) using `/tmp/check_lumos.py` as base — add CLI args for `<api_key> <sheet_id>`, Google Sheets write-back for column C, and full pagination loop